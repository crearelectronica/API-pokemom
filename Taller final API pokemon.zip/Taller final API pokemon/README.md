# Taller de prueba con PokéAPI

#### Aquí se encuentran los datos usados para conectar con la API.

### Profesoor
- Mauricio Ordóñez

### Autor
- Alexander Rincón

### Contacto
- [Profesor](mauricio.munoz.ordonez@gmail.com)(dev.mauricio.munoz@gmail.com)
- [Estudiante](crearelectronica@hotmail.com)

